function val = sigmoid(x)
   val = 1 ./ (1+ exp(-x));
end